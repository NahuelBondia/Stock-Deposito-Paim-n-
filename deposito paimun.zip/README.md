# Control de Stock — Depósito (versión compartida para todo el equipo)

Esta versión guarda el inventario en una base de datos compartida (Redis, vía la integración de Vercel), así que todos ven el mismo stock sin importar desde qué celular o PC entren.

Un detalle importante: **Vercel ya no llama a esto "Vercel KV"** — lo renombraron y ahora se contrata como una integración de **Redis (Upstash)** desde el mismo panel de Vercel, gratis en el plan Hobby. El código ya está preparado para esa integración.

## Qué incluye esta carpeta
- `index.html` — la app (interfaz).
- `api/inventario.js` — la función que lee y guarda el inventario en la base de datos.
- `package.json` — la única dependencia necesaria.

## Pasos para publicarla

### 1. Subir el proyecto a GitHub
- Creá una cuenta gratis en https://github.com si no tenés.
- Creá un repositorio nuevo, por ejemplo `stock-deposito`.
- Subí las 3 cosas de esta carpeta manteniendo la estructura: `index.html`, `package.json`, y la carpeta `api` con `inventario.js` adentro (con **Add file → Upload files** podés arrastrar la carpeta completa).

### 2. Importar el proyecto en Vercel
- Entrá a https://vercel.com, creá cuenta gratis (podés usar tu cuenta de GitHub).
- **Add New… → Project** y elegí el repositorio `stock-deposito`.
- Dejá la configuración por defecto y hacé clic en **Deploy**.

### 3. Agregar la base de datos (Redis)
- Una vez desplegado, entrá al proyecto en Vercel y andá a la pestaña **Storage**.
- Hacé clic en **Create Database** (o **Browse Marketplace**) y elegí **Redis** (provisto por Upstash).
- Seguí los pasos por defecto (plan gratuito) y conectala a tu proyecto `stock-deposito`.
- Esto crea automáticamente las variables de entorno `KV_REST_API_URL` y `KV_REST_API_TOKEN` que usa `api/inventario.js` — no hay que copiar nada a mano.

### 4. Volver a desplegar
- Después de conectar la base de datos, andá a la pestaña **Deployments** del proyecto y hacé clic en **Redeploy** en el último deploy (así toma las variables nuevas).
- Te va a quedar una URL propia, por ejemplo `stock-deposito.vercel.app`, para que use todo el equipo desde donde quiera.

## Cómo queda funcionando
- Cualquier persona que entre a la URL ve y actualiza el **mismo** inventario.
- Los cambios de otra persona se ven al usar el botón **🔄 Actualizar**, o solos cada 20 segundos automáticamente.
- El escaneo de código de barras funciona por cámara del celular, con permiso del navegador (al estar en un dominio propio con HTTPS funciona bien).

## Si algo falla
- Si al abrir la app aparece un error al guardar/leer, revisá en Vercel → Storage que la base de datos Redis esté **conectada a este proyecto** y que hayas hecho **Redeploy** después de conectarla.
